<?php
    /*
    Plugin Name: General Setting
    Description: Listing of all General Settings with system.
    Version: 1.0
    Author: Redspark Technology
    Author URI: http://www.redsparkinfo.com
    */
    add_action('admin_menu','init_redsparkgeneral_settings_plugin');
    function init_redsparkgeneral_settings_plugin(){    
        add_menu_page('General Setting', 'General Setting', 8, 'redsparkgeneral_settings', 'redsparkgeneral_settings',"",80); 
    }
    function redsparkgeneral_settings()
    {
        global $current_user;
        if ( is_user_logged_in() ) {
            $ufUserID = $current_user->ID;
            $site_logo_url = sanitize_text_field($_POST['site_logo_url']) ;
            $addr = sanitize_text_field($_POST['addr']);
            //  $addr2 = $_POST['addr2'];
            $email_id = sanitize_text_field($_POST['email_id']);
            //  $email_id2 = $_POST['email_id2'];
            // $website = $_POST['website'];
            // $footer_text = $_POST['footer_text'];
            $notification_email_id = sanitize_text_field($_POST['notification_email_id']);
            $phone_no = sanitize_text_field($_POST['phone_no']);
            $copyright = sanitize_text_field($_POST['copyright']);
            $facebook_url = sanitize_text_field($_POST['facebook_url']);
            $twitter_url = sanitize_text_field($_POST['twitter_url']);
            $google_url = sanitize_text_field($_POST['google_url']);
            $linkedin_url = sanitize_text_field($_POST['linkedin_url']);
            $rss_url = sanitize_text_field($_POST['rss_url']);
            // $instagram_url = $_POST['instagram_url'];

            if ( 'POST' == $_SERVER['REQUEST_METHOD'] && !empty( $_POST['action'] ) && $_POST['action'] == 'updateFeedback' ) {
                update_option('rs_site_logo_url', $site_logo_url);
                update_option('rs_address', $addr);
                //  update_option('rs_address2', $addr2);
                update_option('rs_email_id', $email_id);
                //  update_option('rs_email_id2', $email_id2);
                //  update_option('rs_website', $website);
                // update_option('rs_footer_text', $footer_text);
                update_option('rs_notification_email_id', $notification_email_id);
                update_option('rs_phone_no', $phone_no);
                update_option('rs_copyright', $copyright);
                update_option('rs_facebook_url', $facebook_url);
                update_option('rs_twitter_url', $twitter_url);
                update_option('rs_google_url', $google_url);
                update_option('rs_linkedin_url', $linkedin_url);
                update_option('rs_rss_url', $rss_url);
                //  update_option('rs_instagram_url', $instagram_url);
                $flag_gen = true; 
            }
        ?>
        <div class="wrap">
            <?php screen_icon('options-general'); ?>
            <h2>General Setting</h2>
            <?php if($flag_gen){ ?>
                <div class="updated settings-error" id="setting-error-settings_updated"> 
                    <p><strong>Settings saved.</strong></p>
                </div>
                <?php } ?>
            <form action="" method="post">
                <?php   wp_nonce_field('user_info', 'user_info_nonce', true, true); ?>
                <table class="form-table">
                    <tbody>
                        <tr valign="top">
                            <th scope="row"><label for="site_logo_url"><?php _e("Header Logo URL: "); ?></label></th>
                            <td>
                                <input type="text" class="regular-text" value="<?php echo stripslashes(urldecode(get_option('rs_site_logo_url'))); ?>" id="site_logo_url" name="site_logo_url">
                                <input id="upload_image_button" type="button" value="Upload" class="button" />
                            </td>
                        </tr>

                        <tr valign="top">
                            <th scope="row"> <label for="email_id"><?php _e('Address: ') ?></label> </th>
                            <td>
                                <textarea name="addr" id="address" class="address regular-text" cols="50" rows="3"><?php echo get_option('rs_address'); ?></textarea>
                                <span class="description"><?php _e('Edit the Address') ?></span>
                            </td>
                        </tr>
                        <tr valign="top">
                            <th scope="row"> <label for="phone_no"><?php _e('Phone Number: ') ?></label> </th>
                            <td>
                                <input name="phone_no" type="text" id="phone_no" value="<?php echo get_option('rs_phone_no'); ?>" class="regular-text" />
                                <span class="description"><?php _e('Edit the Phone no') ?></span>
                            </td>
                        </tr>
                        <tr valign="top">
                            <th scope="row"> <label for="email_id"><?php _e('Email: ') ?></label> </th>
                            <td>
                                <input name="email_id" type="text" id="email_id" value="<?php echo get_option('rs_email_id'); ?>" class="regular-text" />
                                <span class="description"><?php _e('Edit the Email id') ?></span>
                            </td>
                        </tr>
                        <tr valign="top">
                            <th scope="row"> <label for="notification_email_id"><?php _e('Notification Email Id: ') ?></label> </th>
                            <td>
                                <input name="notification_email_id" type="text" id="notification_email_id" value="<?php echo get_option('rs_notification_email_id'); ?>" class="regular-text" />
                                <span class="description"><?php _e('Edit the Notification Email id') ?></span>
                            </td>
                        </tr>
                        <tr valign="top">
                            <th scope="row"> <label for="copyright"><?php _e('Copy Right: ') ?></label> </th>
                            <td>
                                <input name="copyright" type="text" id="copyright" value="<?php echo get_option('rs_copyright'); ?>" class="regular-text" />
                                <span class="description"><?php _e('Edit the Copy right') ?></span>
                            </td>
                        </tr>
                        <tr valign="top">
                            <th colspan="2"> <h2> Social Links </h2> </td>
                        </tr>
                        <tr valign="top">
                            <th scope="row"> <label for="facebook_url"><?php _e('Facebook Url: ') ?></label> </th>
                            <td>
                                <input name="facebook_url" type="text" id="facebook_url" value="<?php echo get_option('rs_facebook_url'); ?>" class="regular-text" />
                                <span class="description"><?php _e('Edit the Facebook url') ?></span>
                            </td>
                        </tr>
                        <tr valign="top">
                            <th scope="row"> <label for="twitter_url"><?php _e('Twitter Url: ') ?></label> </th>
                            <td>
                                <input name="twitter_url" type="text" id="twitter_url" value="<?php echo get_option('rs_twitter_url'); ?>" class="regular-text" />
                                <span class="description"><?php _e('Edit the Twitter url') ?></span>
                            </td>
                        </tr>
                        <tr valign="top">
                            <th scope="row"> <label for="linkedin_url"><?php _e('Linkedin_url Url: ') ?></label> </th>
                            <td>
                                <input name="linkedin_url" type="text" id="linkedin_url" value="<?php echo get_option('rs_linkedin_url'); ?>" class="regular-text" />
                                <span class="description"><?php _e('Edit the Linkedin_url Url ') ?></span>
                            </td>
                        </tr>
                        <tr valign="top">
                            <th scope="row"> <label for="google_url"><?php _e('Google plus Url: ') ?></label> </th>
                            <td>
                                <input name="google_url" type="text" id="google_url" value="<?php echo get_option('rs_google_url'); ?>" class="regular-text" />
                                <span class="description"><?php _e('Edit the Google plus Url') ?></span>
                            </td>
                        </tr>
                        <tr valign="top">
                            <th scope="row"> <label for="rss_url"><?php _e('Rss Url: ') ?></label> </th>
                            <td>
                                <input name="rss_url" type="text" id="rss_url" value="<?php echo get_option('rs_rss_url'); ?>" class="regular-text" />
                                <span class="description"><?php _e('Edit the Rss Url ') ?></span>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <p class="submit">
                    <input type="submit" value="Save Changes" class="button-primary" id="submit" name="gen_submit">
                    <?php wp_nonce_field( 'updateFeedback' ); ?>
                    <input name="action" type="hidden" id="action" value="updateFeedback" />
                </p>
            </form>
        </div>
        <script language="JavaScript">
            jQuery(document).ready(function() {
                jQuery('#upload_image_button').click(function() {
                    var original_send_to_editor = window.send_to_editor;
                    formfield = jQuery('#site_logo_url').attr('name');
                    tb_show('', 'media-upload.php?type=image&TB_iframe=true');
                    window.send_to_editor = function(html_val) {
                        if(jQuery(html_val).attr('src')) {
                            imgurl = jQuery(html_val).attr('src');
                        }
                        else {
                            imgurl = jQuery(html_val).attr('href');
                        }
                        jQuery('#site_logo_url').val(imgurl);
                        tb_remove();
                        window.send_to_editor = original_send_to_editor;
                    }
                    return false;
                });        
            });
        </script>
        <?php }
    ?>
    <?php
    }
?>