﻿=== General Settings ===
Contributors: General Settings
Tags: general  settings, theme settings,social settings

License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

general  settings, theme settings,social settings

== Description ==

general  settings, theme settings,social settings