<?php
    // parse_str($_POST['data'], $_POST);

    $response = array();
    global $wpdb;
    // global $data; 
    if(isset($_POST)){
        // $url = bloginfo('template_url') ;

        $url =   get_theme_root(); 
        /// $url = "E:/xampp/htdocs/etax/wp-content/themes/etax";
        require_once($url.'/etax/Stripe/lib/Stripe.php');
        try {
            Stripe::setApiKey("sk_test_9Y66vhjMznY9TyXK1fl4bSgg");
            Stripe_Charge::create(array("amount" => $_POST['amount'],
            "currency" => $_POST['currency'],
            "card" => $_POST['stripeToken'],
            "description" => "Charge Tax Retrun Form"   
            ));
      /*    $success = '<div class="alert alert-success">
            <strong>Success!</strong> Your payment was successful.
             </div>';*/
            $success = 1;         
        }
        
        catch(Stripe_CardError $e) {
            $error1   = '<div class="alert alert-danger">
            <strong>Error!</strong> '.$e->getMessage().'
            </div>';
           //  $message1 = $e->getMessage();
                   
        } catch (Stripe_InvalidRequestError $e) {

            $error2 = '<div class="alert alert-danger">
            <strong>Error!</strong> '.$e->getMessage().'
            </div>';
           // $message2 = $e->getMessage();
          
            
        } catch (Stripe_AuthenticationError $e) {

           $error3 = '<div class="alert alert-danger">
            <strong>Error!</strong> '.$e->getMessage().'
            </div>';
          //  $message3 = $e->getMessage();
          
        } catch (Stripe_ApiConnectionError $e) {
            $error4 = '<div class="alert alert-danger">
            <strong>Error!</strong> '.$e->getMessage().'
            </div>';
           // $message4 = $e->getMessage();

        } catch (Stripe_Error $e) {
            $error5 = '<div class="alert alert-danger">
            <strong>Error!</strong> '.$e->getMessage().'
            </div>';
          //  $message5 = $e->getMessage();

        } catch (Exception $e) {
            $error6 = '<div class="alert alert-danger">
            <strong>Error!</strong> '.$e->getMessage().'
            </div>';
        ///    $message6 = $e->getMessage();
           
        }

         if($success != 1){
            // echo "1";
            echo $error1;         
            echo $error2;
            echo $error3; 
            echo $error4; 
            echo $error5; 
            echo $error6;
     
        }else{  
            $upload_dir    = wp_upload_dir();   
            $upload_dir1    = $upload_dir['baseurl'] ;

            $no_files = count($_FILES["files"]['name']);
            $images_arr = array();
            for ($i = 0; $i < $no_files; $i++) {  
                //move_uploaded_file($_FILES["files"]["tmp_name"][$i], 'uploads/' . $_FILES["files"]["name"][$i]);
                //      echo 'File successfully uploaded : uploads/' . $_FILES["files"]["name"][$i] . ' ';
                $uploads = wp_upload_dir(); 
                $upload_dir = $uploads['basedir']; 
                $upload_dir1 = $uploads['baseurl']; 

                $new_upload= $upload_dir."/Document/";  
                $new_upload1= $upload_dir1."/Document/";

                $file = $new_upload .basename($_FILES['files']['name'][$i]);
                $img = $_FILES['files']['name'][$i] ;
                $file1 = $new_upload1."".$img; 

                move_uploaded_file($_FILES['files']['tmp_name'][$i], $file);
                $images_arr[] = $img;

            }

            $all_images = implode(",",$images_arr);

            $type_retrun   = $_POST['type_retrun'];                  
            $tfn  = $_POST['tfn'];
            $name = $_POST['name'];
            $phone = $_POST['phone'];
            $email_id = $_POST['email_id'];
            $contact_person = $_POST['contact_person'];



            $data = array(
            "tfn"=>$tfn,
            "name"=>$name,
            "email"=>$phone,
            "phone"=>$email_id,
            "contact_person"=>$contact_person,
            "attachment"=> $all_images,
            "type_entity"=> $type_retrun,

            );

            //  echo "<pre>"; print_r($data); "</pre>"; die();
            $insert = $wpdb->insert("wp_buaniess_return",$data);


            echo "1";
           /*
            $to = get_option('admin_email');
            $subject = "Etax Busniess Tax Return Enquiry";

            $message="<h2>ETax Busniess Enquiry</h2><br />";
            $message.="<style type='text/css'>
            #sign{
            display:none;
            }
            a { color: #2D7BE0; }
            a:hover { text-decoration: none; }
            </style>
            <table style='background: #eee; padding-left:10px;' width='100%'>
            <tr>
            <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> Return type </th>
            <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$type_retrun."</td>
            </tr> 
            <tr>
            <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> TFN </th>
            <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$tfn."</td>
            </tr>

            <tr>
            <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> Name  </th>
            <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$name."</td>
            </tr> 

            <tr>
            <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'>Email</th>
            <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$email_id."</td>
            </tr>
            <tr>
            <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'>Phone Number </th>
            <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$phone."</td>
            </tr>
            <tr>
            <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> Contact Person </th>
            <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$contact_person."</td>
            </tr>";
            $i = 1;
            foreach($images_arr as $key){
            $message.= "   
            <tr>
            <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> Attechment ".$i." </th>
            <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'><a href='".$upload_dir1."/Document/".$key."'>".$key."</a></td>
            </tr>";
            $i++;   }
            $message.= "</table>";  
            $headers = 'From: ETax <'.get_option('admin_email').'>'. "\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
            wp_mail( $to, $subject, $message, $headers );
            $emailSent = true;  
            */    

        }
    }
    /*if(isset($_POST)){ 
    $typereturn=$_POST['typereturn']; 
    $tfn=$_POST['tfn']; 
    $name=$_POST['name']; 
    $phone=$_POST['phone']; 
    $email_id=$_POST['email_id']; 

    $contact_person=$_POST['contact_person']; 

    $img = $_POST['upload_file']; 
    //  echo $tfn ,$name, $phone,$email_id,  $contact_person,$img;

    $uploads = wp_upload_dir(); 
    $upload_dir=$uploads['basedir']; 
    $upload_dir1=$uploads['baseurl']; 

    $new_upload= $upload_dir."/upload_image/";  
    $new_upload1= $upload_dir1."/upload_image/";

    $file = $new_upload . $img ;
    $file1 = $new_upload1."".$img; 

    move_uploaded_file($file1, $img);


    $data = array(
    "tfn"=>$tfn,
    "name"=>$name,
    "email"=>$phone,
    "phone"=>$email_id,
    "contact_person"=>$contact_person,
    "attachment"=> $img,
    "type_entity"=> $typereturn,

    );
    // echo "<pre>"; print_r($data); "</pre>";
    $insert = $wpdb->insert("wp_buaniess_return",$data);
    if($insert)
    {
    echo "1";
    }
    else
    {
    echo "2";
    }       
    } */
?>