<?php
     function busniess_return() {
        if ( isset($_REQUEST) ) {
            $dirName = dirname(__FILE__);
            require_once ("$dirName/ajax/busniess_return.php"); 
        }
        die();
    }
    add_action( 'wp_ajax_busniess_return', 'busniess_return' );
    add_action( 'wp_ajax_nopriv_busniess_return', 'busniess_return' );
?>
   
