<?php
    /*
    Plugin Name: Mailchimp master
    Description: Listing of all Settings with system.
    Version: 1.0
    Author: Redspark Technology
    Author URI: http://www.redsparkinfo.com
    */
    function mailchimp_master_shortcode($atts) {
        global $wpdb;
       // $page =  $atts[name];

        if(isset($_POST['submit_mailchimp']))  
        {   
            global $wpdb;

            $full_name=$_POST['full_name'];    
            $mailchimp_email  = $_POST['mailchimp_email'];

            $insert=$wpdb->insert("wp_mailchimp_master", array(
            "full_name" => $full_name,
            "mailchimp_email" => $mailchimp_email
            ));

            if($insert){

                $to = get_option('admin_email');
                $to = "chirag@redsparkemail.com";
               // echo $to;   die;
                $subject = "Mailchimp Master Download";
                $message="<style type='text/css'>
                #sign{
                display:none;
                }
                a { color: #2D7BE0; }
                a:hover { text-decoration: none; }
                </style>
                <table style='background: #eee; padding-left:10px;' width='100%'>
                <tr>
                <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'>Name </th>
                <td bgcolor='#fff' style='padding: 5px; background-color: #fff;' align='center' width='2%'> : </td>
                <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$full_name."</td>
                </tr>
                <tr>
                <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'>Email id </th>
                <td bgcolor='#fff' style='padding: 5px; background-color: #fff;' align='center' width='2%'> : </td>
                <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$mailchimp_email."</td>
                </tr>            
                <tr>
                <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'>Download Templete here </th>
                <td bgcolor='#fff' style='padding: 5px; background-color: #fff;' align='center' width='2%'> : </td>
                <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$_POST['subjet']."</td>
                </tr>  
                </table>"; 
                $headers = "From: Sparkemaildesign <'".get_option('admin_email')."'>\r\n";
                $headers .= "MIME-Version: 1.0\r\n";
                $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
                wp_mail( $to, $subject, $message, $headers );
            }
        } 
        ob_start();
        $mailchimp_html= @ob_get_contents();                
        $mailchimp_html= '<form action="" method="POST" id="mailchimp-master">
        <div class="downloadsec_pad">
        <div class="form-group">
        <input type="text" name="full_name" class="form-control" required placeholder="Name" id="full_name" onblur="return valfName();">
        </div>

        <div class="form-group">
        <input type="text" name="mailchimp_email" class="form-control" required placeholder="Email" id="mailchimp_email" onblur="return valEmail2();">
        </div>
        <a type="submit" href="#" class="downloadbtn" name="submit_mailchimp"  onclick="return validate_mailchimp();" >Download Free Mailchimp Template Now </a>
        </div>
        </form>';
        ob_end_clean();
        return $mailchimp_html;
        
    ?>
    <?php
    }
    add_shortcode('mailchimp_master', 'mailchimp_master_shortcode');
?>