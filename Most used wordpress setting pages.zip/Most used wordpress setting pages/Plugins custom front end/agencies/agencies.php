<?php
    /*
    Plugin Name:  Agencies
    Description: Listing of all Settings with system.
    Version: 1.0
    Author: Redspark Technology
    Author URI: http://www.redsparkinfo.com
    */
    function agencies_shortcode($atts) {
        global $wpdb;
        $page =  $atts[name];

        if(isset($_POST['submit_agencies']))  
        {   
            global $wpdb;

            $first_name=$_POST['first_name'];    
            $agencies_email  = $_POST['agencies_email'];
            $agencies_phone  = $_POST['agencies_phone'];
            $messages  = $_POST['messages'];

            $insert=$wpdb->insert("wp_agencies", array(
            "first_name" => $first_name,
            "agencies_email" => $agencies_email,
            "agencies_phone" => $agencies_phone,
            "messages" => $messages
            ));

            if($insert){

                $to = get_option('admin_email');
                $to = "chirag@redsparkemail.com";
                echo $to;   die;
                $subject = "Agencies";
                $message="<style type='text/css'>
                #sign{
                display:none;
                }
                a { color: #2D7BE0; }
                a:hover { text-decoration: none; }
                </style>
                <table style='background: #eee; padding-left:10px;' width='100%'>
                <tr>
                <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'>Name </th>
                <td bgcolor='#fff' style='padding: 5px; background-color: #fff;' align='center' width='2%'> : </td>
                <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$first_name."</td>
                </tr>
                <tr>
                <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'>Email id </th>
                <td bgcolor='#fff' style='padding: 5px; background-color: #fff;' align='center' width='2%'> : </td>
                <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$agencies_email."</td>
                </tr>  
                <tr>
                <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'>Contact </th>
                <td bgcolor='#fff' style='padding: 5px; background-color: #fff;' align='center' width='2%'> : </td>
                <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$agencies_phone."</td>
                </tr>            
                <tr>
                <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'>Message</th>
                <td bgcolor='#fff' style='padding: 5px; background-color: #fff;' align='center' width='2%'> : </td>
                <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$messages."</td>
                </tr>                      
                </table>"; 
                $headers = "From: Sparkemaildesign <'".get_option('admin_email')."'>\r\n";
                $headers .= "MIME-Version: 1.0\r\n";
                $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
                wp_mail( $to, $subject, $message, $headers );
            }
        } 
        ob_start();
        $agencies_html= @ob_get_contents();                
        $agencies_html= '
        <div class="row">
        <form role="form" class="join_form go-right" method="post" id="agencies">
        <div class="col-sm-6">

        <div class="form-group">
        <input id="first_name" name="first_name" type="text" class="form-control" required onblur="return valfirstName();">
        <label for="name">Your Name</label>
        </div>
        <div class="form-group">
        <input id="agencies_email" name="agencies_email" type="text" class="form-control" required onblur="return valagencyemail();">
        <label for="Email">Email</label>
        </div>
        <div class="form-group">
        <input id="agencies_phone" name="agencies_phone" type="tel" class="form-control" required onblur="return valContacts();">
        <label for="phone"> Phone</label>
        </div>
        </div>
        <div class="col-sm-6">
        <div class="form-group">
        <textarea name="messages" rows="6" required class="form-control" id="messages" onblur="return valdesc();"></textarea>
        <label for="message">Message</label>
        </div>
        </div>
        <div class="col-sm-12">
        <a type="submit" class="submit_btn" href="#" name="submit_agencies" onclick="return validate_agencies();">Submit</a>
        </div>
        </form>
        </div>';
        ob_end_clean();
        return $agencies_html;
    ?>
    <?php
    }
    add_shortcode('agencies', 'agencies_shortcode');
?>